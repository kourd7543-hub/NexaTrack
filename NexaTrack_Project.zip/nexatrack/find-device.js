// ========== FIND DEVICE SCRIPT ==========

function showToast(msg, type = 'info') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = 'toast show ' + type;
  setTimeout(() => toast.className = 'toast', 3500);
}

function findByPhone() {
  const phone = document.getElementById('phoneInput').value.trim();
  if (!phone) { showToast('Please enter a phone number!', 'error'); return; }

  // Validate basic phone format
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  if (cleaned.length < 10) { showToast('Enter a valid phone number.', 'error'); return; }

  const trackingLink = `${window.location.origin}/index.html`;
  const message = encodeURIComponent(
    `🔍 Someone is trying to locate this device using TrackSphere.\n\nIf this is your device, please click the link to share your current location:\n${trackingLink}\n\n⚠️ Only respond if you recognize this request.`
  );

  // Try WhatsApp first
  const waNum = cleaned.startsWith('+') ? cleaned.slice(1) : cleaned;
  const waLink = `https://wa.me/${waNum}?text=${message}`;

  // Show options modal
  const box = document.getElementById('lastLocationBox');
  box.innerHTML = `
    <div class="recovery-options">
      <p><strong>Send location request to: ${phone}</strong></p>
      <div class="recovery-btns">
        <a href="${waLink}" target="_blank" class="btn-whatsapp">
          <i class="fa-brands fa-whatsapp"></i> Send via WhatsApp
        </a>
        <a href="sms:${cleaned}?body=${message}" class="btn-sms">
          <i class="fa-solid fa-message"></i> Send via SMS
        </a>
      </div>
      <p class="find-note"><i class="fa-solid fa-circle-info"></i> 
        When the device owner opens the link and clicks "Track My Location", their live location will be shared with you via Google Maps.
      </p>
    </div>
  `;
  showToast('Choose how to send the request!', 'success');
}

function findByCode() {
  const code = document.getElementById('codeInput').value.trim().toUpperCase();
  if (!code) { showToast('Please enter a device code!', 'error'); return; }

  // Check local storage for code
  const saved = localStorage.getItem('ts_shared_' + code);
  if (saved) {
    const data = JSON.parse(saved);
    showRecoveryResult(data);
  } else {
    // Try to parse as coordinates or Google Maps link
    if (code.includes('MAPS.GOOGLE')) {
      window.open(code, '_blank');
    } else {
      showToast(`Code "${code}" not found. Make sure it was generated on this device/browser.`, 'error');
    }
  }
}

function showRecoveryResult(data) {
  const box = document.getElementById('lastLocationBox');
  box.innerHTML = `
    <div class="recovery-result">
      <div class="result-icon"><i class="fa-solid fa-circle-check"></i></div>
      <h4>Device Location Found!</h4>
      <div class="result-details">
        <p><i class="fa-solid fa-globe"></i> Coordinates: <strong>${data.lat}, ${data.lon}</strong></p>
        <p><i class="fa-solid fa-clock"></i> Recorded: <strong>${data.time}</strong></p>
        <p><i class="fa-solid fa-tag"></i> Code: <strong>${data.code}</strong></p>
      </div>
      <div class="result-actions">
        <a href="${data.link}" target="_blank" class="btn-primary">
          <i class="fa-solid fa-map"></i> Open in Google Maps
        </a>
        <button class="btn-secondary" onclick="showOnLeaflet(${data.lat}, ${data.lon})">
          <i class="fa-solid fa-location-dot"></i> Show on Map
        </button>
      </div>
    </div>
  `;

  document.getElementById('recoveryMap').style.display = 'block';
  showToast('Device location found!', 'success');
}

function showOnLeaflet(lat, lon) {
  const mapDiv = document.getElementById('recoveryMap');
  mapDiv.style.display = 'block';
  mapDiv.style.height = '350px';
  mapDiv.style.marginTop = '20px';
  mapDiv.style.borderRadius = '10px';

  const rMap = L.map('recoveryMap').setView([lat, lon], 15);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap'
  }).addTo(rMap);

  const icon = L.divIcon({
    className: '',
    html: '<div class="custom-marker lost"><i class="fa-solid fa-mobile-screen-button"></i></div>',
    iconSize: [40, 40],
    iconAnchor: [20, 40]
  });
  L.marker([lat, lon], { icon }).addTo(rMap).bindPopup('<b>Last Known Device Location</b>').openPopup();
}

function loadLastKnown() {
  const saved = localStorage.getItem('ts_last_location');
  const box = document.getElementById('lastLocationBox');

  if (!saved) {
    box.innerHTML = `
      <div class="no-history">
        <i class="fa-solid fa-triangle-exclamation"></i>
        No saved location found. 
        <strong>To enable recovery, visit the Home page and click "Track My Location" first.</strong>
        <br><br>
        <a href="index.html" class="btn-primary" style="display:inline-block; margin-top:10px">
          <i class="fa-solid fa-home"></i> Go to Home Page
        </a>
      </div>
    `;
    return;
  }

  const data = JSON.parse(saved);
  const googleLink = `https://maps.google.com/?q=${data.lat},${data.lon}`;

  box.innerHTML = `
    <div class="recovery-result">
      <div class="result-icon"><i class="fa-solid fa-circle-check"></i></div>
      <h4>Last Known Location Found!</h4>
      <div class="result-details">
        <p><i class="fa-solid fa-globe"></i> Latitude: <strong>${data.lat.toFixed(6)}</strong></p>
        <p><i class="fa-solid fa-globe"></i> Longitude: <strong>${data.lon.toFixed(6)}</strong></p>
        <p><i class="fa-solid fa-bullseye"></i> Accuracy: <strong>${data.accuracy} meters</strong></p>
        <p><i class="fa-solid fa-clock"></i> Recorded: <strong>${data.time}</strong></p>
      </div>
      <div class="result-actions">
        <a href="${googleLink}" target="_blank" class="btn-primary">
          <i class="fa-solid fa-map"></i> Open in Google Maps
        </a>
      </div>
    </div>
  `;

  document.getElementById('recoveryMap').style.display = 'block';
  showOnLeaflet(data.lat, data.lon);
  showToast('Last known location loaded!', 'success');
}
